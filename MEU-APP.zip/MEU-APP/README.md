# To Do App Simples Centralizado

Projeto em **Expo + React Native + JavaScript**.

## O que tem no app
- React Native
- AsyncStorage
- Navigation
- Adicionar tarefa
- Editar tarefa
- Excluir tarefa
- Marcar como concluída
- Código centralizado no `App.js`

## Como instalar
```bash
npm install
npx expo install --fix
npx expo start -c
```
