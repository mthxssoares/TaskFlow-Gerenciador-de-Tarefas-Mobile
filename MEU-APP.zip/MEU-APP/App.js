import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert,
  FlatList,
  Platform,
  Pressable,
  SafeAreaView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  UIManager,
  View,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { NavigationContainer, useFocusEffect } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Icon from 'react-native-vector-icons/MaterialIcons';

const Stack = createNativeStackNavigator();
const STORAGE_KEY = '@tarefas_app';

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

async function salvarTarefasNoCelular(tarefas) {
  try {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(tarefas));
  } catch (error) {
    console.log('Erro ao salvar:', error);
  }
}

async function buscarTarefasNoCelular() {
  try {
    const tarefasSalvas = await AsyncStorage.getItem(STORAGE_KEY);
    return tarefasSalvas ? JSON.parse(tarefasSalvas) : [];
  } catch (error) {
    console.log('Erro ao carregar:', error);
    return [];
  }
}

function HomeScreen({ navigation }) {
  const [tarefas, setTarefas] = useState([]);
  const [carregando, setCarregando] = useState(true);

  const carregarTarefas = async () => {
    const lista = await buscarTarefasNoCelular();
    setTarefas(lista);
    setCarregando(false);
  };

  useEffect(() => {
    carregarTarefas();
  }, []);

  useFocusEffect(
    useCallback(() => {
      carregarTarefas();
    }, [])
  );

  const alternarConclusao = async (id) => {
    const novaLista = tarefas.map((tarefa) =>
      tarefa.id === id ? { ...tarefa, concluida: !tarefa.concluida } : tarefa
    );

    setTarefas(novaLista);
    await salvarTarefasNoCelular(novaLista);
  };

  const excluirTarefa = (id) => {
    Alert.alert('Excluir tarefa', 'Deseja realmente excluir esta tarefa?', [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Excluir',
        style: 'destructive',
        onPress: async () => {
          const novaLista = tarefas.filter((tarefa) => tarefa.id !== id);
          setTarefas(novaLista);
          await salvarTarefasNoCelular(novaLista);
        },
      },
    ]);
  };

  const renderItem = ({ item }) => (
    <View style={[styles.cardTarefa, item.concluida && styles.cardTarefaConcluida]}>
      <Pressable onPress={() => alternarConclusao(item.id)} style={styles.iconeBotao}>
        <Icon
          name={item.concluida ? 'check-circle' : 'radio-button-unchecked'}
          size={28}
          color={item.concluida ? '#16a34a' : '#6b7280'}
        />
      </Pressable>

      <View style={styles.areaTextoTarefa}>
        <Text style={[styles.textoTarefa, item.concluida && styles.textoTarefaConcluida]}>
          {item.titulo}
        </Text>
      </View>

      <View style={styles.areaAcoes}>
        <Pressable
          onPress={() => navigation.navigate('Formulario', { modo: 'editar', tarefa: item })}
          style={styles.iconeBotao}
        >
          <Icon name="edit-note" size={26} color="#2563eb" />
        </Pressable>

        <Pressable onPress={() => excluirTarefa(item.id)} style={styles.iconeBotao}>
          <Icon name="delete-forever" size={25} color="#dc2626" />
        </Pressable>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.topo}>
        <Text style={styles.titulo}>To Do App</Text>
        <Text style={styles.subtitulo}>React Native + AsyncStorage + Navigation</Text>
      </View>

      <Pressable
        style={styles.botaoAdicionar}
        onPress={() => navigation.navigate('Formulario', { modo: 'criar' })}
      >
        <Icon name="add-circle" size={22} color="#ffffff" />
        <Text style={styles.textoBotaoAdicionar}>ADICIONAR TAREFA</Text>
      </Pressable>

      {carregando ? (
        <Text style={styles.mensagemCentral}>Carregando tarefas...</Text>
      ) : tarefas.length === 0 ? (
        <Text style={styles.mensagemCentral}>Nenhuma tarefa cadastrada.</Text>
      ) : (
        <FlatList
          data={tarefas}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.lista}
        />
      )}
    </SafeAreaView>
  );
}

function FormularioScreen({ navigation, route }) {
  const modo = route.params?.modo || 'criar';
  const tarefa = route.params?.tarefa;
  const [texto, setTexto] = useState('');

  useEffect(() => {
    if (modo === 'editar' && tarefa) {
      setTexto(tarefa.titulo);
    }
  }, [modo, tarefa]);

  const salvarTarefa = async () => {
    if (!texto.trim()) {
      Alert.alert('Atenção', 'Digite uma tarefa antes de salvar.');
      return;
    }

    const tarefasAtuais = await buscarTarefasNoCelular();
    let novaLista = [];

    if (modo === 'editar' && tarefa) {
      novaLista = tarefasAtuais.map((item) =>
        item.id === tarefa.id ? { ...item, titulo: texto.trim() } : item
      );
    } else {
      novaLista = [
        {
          id: Date.now().toString(),
          titulo: texto.trim(),
          concluida: false,
        },
        ...tarefasAtuais,
      ];
    }

    await salvarTarefasNoCelular(novaLista);
    navigation.goBack();
  };

  return (
    <SafeAreaView style={styles.containerFormulario}>
      <View style={styles.caixaFormulario}>
        <Text style={styles.tituloFormulario}>
          {modo === 'editar' ? 'Editar tarefa' : 'Nova tarefa'}
        </Text>

        <TextInput
          style={styles.input}
          placeholder={modo === 'editar' ? 'Edite sua tarefa' : 'Digite sua tarefa'}
          placeholderTextColor="#6b7280"
          value={texto}
          onChangeText={setTexto}
          multiline
        />

        <Pressable style={styles.botaoSalvar} onPress={salvarTarefa}>
          <Icon name={modo === 'editar' ? 'save' : 'playlist-add-check-circle'} size={22} color="#fff" />
          <Text style={styles.textoBotaoSalvar}>
            {modo === 'editar' ? 'SALVAR ALTERAÇÕES' : 'SALVAR TAREFA'}
          </Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <StatusBar barStyle="dark-content" backgroundColor="#e5e7eb" />
      <Stack.Navigator
        initialRouteName="Home"
        screenOptions={{
          headerStyle: { backgroundColor: '#ffffff' },
          headerTitleStyle: { fontWeight: 'bold', color: '#111827' },
          headerShadowVisible: false,
          contentStyle: { backgroundColor: '#e5e7eb' },
        }}
      >
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={{ title: 'Lista de Tarefas' }}
        />
        <Stack.Screen
          name="Formulario"
          component={FormularioScreen}
          options={({ route }) => ({
            title: route.params?.modo === 'editar' ? 'Editar Tarefa' : 'Adicionar Tarefa',
          })}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#e5e7eb',
    paddingHorizontal: 18,
    paddingTop: 14,
  },
  topo: {
    marginBottom: 18,
  },
  titulo: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#111827',
    textAlign: 'center',
  },
  subtitulo: {
    marginTop: 4,
    fontSize: 13,
    color: '#6b7280',
    textAlign: 'center',
  },
  botaoAdicionar: {
    backgroundColor: '#5b21b6',
    borderRadius: 14,
    paddingVertical: 14,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    marginBottom: 18,
  },
  textoBotaoAdicionar: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  mensagemCentral: {
    textAlign: 'center',
    marginTop: 30,
    color: '#6b7280',
    fontSize: 16,
  },
  lista: {
    paddingBottom: 22,
  },
  cardTarefa: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 12,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#d1d5db',
  },
  cardTarefaConcluida: {
    opacity: 0.85,
    backgroundColor: '#f8fafc',
  },
  iconeBotao: {
    padding: 4,
  },
  areaTextoTarefa: {
    flex: 1,
    paddingHorizontal: 8,
  },
  textoTarefa: {
    fontSize: 16,
    color: '#111827',
  },
  textoTarefaConcluida: {
    textDecorationLine: 'line-through',
    color: '#6b7280',
  },
  areaAcoes: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
  },
  containerFormulario: {
    flex: 1,
    backgroundColor: '#e5e7eb',
    justifyContent: 'center',
    padding: 20,
  },
  caixaFormulario: {
    backgroundColor: '#ffffff',
    borderRadius: 18,
    padding: 18,
    borderWidth: 1,
    borderColor: '#d1d5db',
  },
  tituloFormulario: {
    fontSize: 25,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 16,
    color: '#111827',
  },
  input: {
    minHeight: 140,
    borderWidth: 1,
    borderColor: '#d1d5db',
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    color: '#111827',
    textAlignVertical: 'top',
    marginBottom: 16,
    backgroundColor: '#f9fafb',
  },
  botaoSalvar: {
    backgroundColor: '#2563eb',
    borderRadius: 14,
    paddingVertical: 14,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  textoBotaoSalvar: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 14,
  },
});
